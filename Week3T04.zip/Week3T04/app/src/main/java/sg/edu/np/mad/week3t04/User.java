package sg.edu.np.mad.week3t04;

import android.util.EventLogTags;

import java.util.jar.Attributes;

public class User {
    public String Name;
    public String Description;
    public Integer Id;
    public Boolean Followed;

    public String getName(){return Name;}
    public String getDescription(){return Description;}

    public User() {
    }

    public User(String name, String description, Integer id, Boolean followed) {
        Name = name;
        Description = description;
        Id = id;
        Followed = followed;
    }




}
