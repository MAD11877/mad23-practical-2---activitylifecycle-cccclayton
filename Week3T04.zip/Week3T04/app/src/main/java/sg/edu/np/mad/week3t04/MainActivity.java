package sg.edu.np.mad.week3t04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    final String TITLE ="Main Activity";
    boolean FollowedStatus = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.v(TITLE, "On Create!");
        User myUser = new User();
        myUser.getDescription();
        myUser.getName();
    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.v(TITLE, "On Start!");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TITLE, "On Pause!");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.v(TITLE, "On Resume");

        Button followButton =findViewById(R.id.button2);
        followButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TITLE, "FollowButton pressed");
                if(FollowedStatus == true){
                    FollowedStatus = false;
                    followButton.setText("Unfollow");
                } else if (FollowedStatus == false) {
                    FollowedStatus = true;
                    followButton.setText("Follow");
                }

            }
        });
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.v(TITLE, "On Destroy");
    }
}